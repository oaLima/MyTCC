document.getElementById("cadsform").addEventListener("submit", async (event) => {
    event.preventDefault();

    const nome = document.getElementById("nome_cliente").value;
    const telefone = document.getElementById("telefone_cliente").value;
    const endereco = document.getElementById("endereco_cliente").value;
    const cnpj = document.getElementById("cnpj_cliente").value;
    const email = document.getElementById("email_cliente").value;
    const senha = document.getElementById("senha_login").value;

    const dados = {
        nome_cliente: nome,
        telefone_cliente: telefone,
        endereco_cliente: endereco,
        cnpj_cliente: cnpj,
        email_cliente: email,
        senha_login: senha
    }

    try {
        const resposta = await fetch("http://localhost:3000/register", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(dados)
        });

        const resultado = await resposta.json();
        if(resposta.ok) {
            alert("Cliente cadastrado!")
            window.location.href = "login.html";
        } else {
            alert ("Erro no cadastro" + resultado.mesagem);
        }
    } catch (erro) {
        console.erro(erro);
        alert("Erro ao conectar ao servidor");
    }
});