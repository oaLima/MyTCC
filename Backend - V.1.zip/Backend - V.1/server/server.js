import http from 'http';
import express from 'express';
import dotenv from 'dotenv';
import conectarBanco from '../conexao/conexao.js';
import bcrypt from "bcrypt";
import cors from "cors";
dotenv.config();

const PORTA = process.env.PORTA || 3000;
const app = express();
app.use(express.json());

app.use(cors({
    origin: "http://127.0.0.1:5500",
    methods: ["GET", "POST", "PUT", "DELETE"],
    credentials: true
}));

// Rota raiz
app.get('/', (req, res) => {
    res.end('Servidor conectado');
});

// Rota listar clientes
app.get('/cliente', async (req, res) => {
    let conexao;
    try {
        conexao = await conectarBanco();
        const sql = 'SELECT * FROM cliente';
        const [linhas] = await conexao.execute(sql);
        res.json(linhas);
    } catch (error) {
        console.error('Erro na conexão', error);
        res.status(500).json({ erro: error.message });
    } finally {
        if (conexao) await conexao.end();
    }
});

// Rota de registro
app.post("/register", async (req, res) => {
    let conexao;
    try {
        const {
            nome_cliente,
            cnpj_cliente,
            telefone_cliente,
            endereco_cliente,
            email_cliente,
            senha_login
        } = req.body;

        if (!nome_cliente || !cnpj_cliente || !telefone_cliente || !endereco_cliente || !email_cliente || !senha_login) {
            return res.status(400).send("Todos os campos são obrigatórios");
        }

        conexao = await conectarBanco();

        // Inserindo cliente
        const [resultadoCliente] = await conexao.execute(
            `INSERT INTO cliente (nome_cliente, cnpj_cliente, telefone_cliente, endereco_cliente, email_cliente) VALUES (?, ?, ?, ?, ?)`,
            [nome_cliente, cnpj_cliente, telefone_cliente, endereco_cliente, email_cliente]
        );

        const id_cliente = resultadoCliente.insertId;

        // Criptografando senha
        const hash = await bcrypt.hash(senha_login, 10);

        // Inserindo senha no login
        await conexao.execute(
            `INSERT INTO login (senha_login, fk_id_cliente) VALUES (?, ?)`,
            [hash, id_cliente]
        );

        res.status(201).send("Cliente cadastrado com sucesso");

    } catch (erro) {
        console.error(erro);
        res.status(500).send("Erro no cadastro");
    } finally {
        if (conexao) await conexao.end();
    }
});

// Rota de login
app.post("/login", async (req, res) => {
    let conexao;
    try {
        const { email_cliente, senha_login } = req.body;

        if (!email_cliente || !senha_login) {
            return res.status(400).send("Email e senha são obrigatórios");
        }

        conexao = await conectarBanco();

        const [clientes] = await conexao.execute(
            `SELECT cliente.*, login.senha_login 
             FROM cliente 
             JOIN login ON cliente.id_cliente = login.fk_id_cliente 
             WHERE email_cliente = ?`,
            [email_cliente]
        );

        if (clientes.length === 0) {
            return res.status(404).send("Cliente não localizado");
        }

        const cliente = clientes[0];
        const senhaCorreta = await bcrypt.compare(senha_login, cliente.senha_login);

        if (senhaCorreta) {
            res.status(200).send("Login correto");
        } else {
            res.status(401).send("Senha incorreta");
        }

    } catch (erro) {
        console.error(erro);
        res.status(500).send("Erro ao fazer login");
    } finally {
        if (conexao) await conexao.end();
    }
});

// Criação do servidor
const server = http.createServer(app);
server.listen(PORTA, () => {
    console.log(`Servidor rodando em http://localhost:${PORTA}`);
});
