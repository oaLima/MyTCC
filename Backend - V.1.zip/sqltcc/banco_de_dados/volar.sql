create database volar;
use volar;

create table cliente(
	id_cliente int primary key auto_increment not null,
    nome_cliente varchar (125) not null,
    email_cliente varchar (100) not null,
    tel_cliente char (11) not null,
    constraint tel_cliente check (tel regexp '^[0-9]+$'),
    cpf_cliente char (11) not null,
    constraint cpf_cliente check (cpf regexp '^[0-9]+$')
);

create table produto(
	id_produto int auto_increment primary key not null,
    nome_produto varchar (125) not null,
    preco_produto decimal (10, 2),
    desc_produto varchar (200) not null,
    status_produto enum ("Pago", "Pendente", "Cancelado")
);

create table pedido(
	id_pedido int primary key auto_increment not null,
    id_cliente int,
    id_produto int,
    constraint fk_id_produto foreign key (fk_id_produto) references produto(id),
    constraint fk_id_cliente foreign key (fk_id_cliente) references cliente(id),
    data_pedido timestamp default current_timestamp
);

-- crear indices para facilitar nas buscas --------------------

