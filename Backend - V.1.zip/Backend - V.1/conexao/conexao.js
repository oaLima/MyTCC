import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

const dbConfig = {
    host: process.env.HOST,
    user: process.env.USER,
    password: process.env.PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.PORT,
    db_port: process.env.DB_PORT
};

export async function conectarBanco() {
    try{
        const connection = await mysql.createConnection(dbConfig);
        console.log("conectado")
        return connection;
    } catch (e){
        console.log("Erro na conexão" + e.message);
        throw error;
    }
}

export default conectarBanco;