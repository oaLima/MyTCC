create database petclean;
use petclean;

create table cliente(
	id_cliente int auto_increment primary key,
    nome_cliente varchar (100) not null,
    cnpj_cliente char (14) not null unique,
	constraint chk_cnpj check (cnpj_cliente regexp '^[0-9]{14}$'),
    telefone_cliente char (11) not null,
    constraint chk_telefone check (telefone_cliente regexp '^[0-9]{11}$'),
    ativo_cliente boolean default 1,
    endereco_cliente varchar (145) not null,
    data_cliente timestamp default current_timestamp,
    email_cliente varchar (125) not null unique
);

create table toalha(
	id_toalha int auto_increment primary key,
    tipo_toalha enum ("Limpas", "Manchadas", "Sujas", "Rasgadas"),
    qtd_toalha int 
);

create table entrada(
	id_entrada int auto_increment primary key,
    data_entrada timestamp default current_timestamp,
    fk_id_cliente int,
    fk_id_toalha int,
    foreign key (fk_id_cliente) references cliente(id_cliente),
    foreign key (fk_id_toalha) references toalha(id_toalha)
);
create table saida(
	id_saida int auto_increment primary key,
    data_saida timestamp default current_timestamp,
	fk_id_cliente int,
    fk_id_toalha int,
    foreign key (fk_id_cliente) references cliente(id_cliente),
    foreign key (fk_id_toalha) references toalha(id_toalha)
);

create table login(
	id_login int auto_increment primary key,
    senha_login varchar (100) not null,
    fk_id_cliente int,
    foreign key (fk_id_cliente) references cliente(id_cliente)
);

-- ----------------------------------------

insert into cliente(nome_cliente, cnpj_cliente, telefone_cliente, endereco_cliente, email_cliente)
values("teste2", "11111111111211", "11112111111", "rua teste de teste2", "teste2@email.com");

insert into login (fk_id_cliente, senha_login)
values (last_insert_id(1), '12345678');

delete from login where id_login = 1;

select * from cliente;
select * from login;
