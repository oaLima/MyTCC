document.getElementById("loginform").addEventListener("submit", async (event) => {
    event.preventDefault(); // evita recarregar a página

    const email = document.getElementById("email_cliente").value;
    const senha = document.getElementById("senha_login").value;

    const dados = {
        email_cliente: email,
        senha_login: senha
    };

    const mensagem = document.getElementById("mensagem");

    try {
        const resposta = await fetch("http://localhost:3000/login", {
            method: "POST", 
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(dados)
        });

        const texto = await resposta.text();

        if (resposta.ok) {
            mensagem.style.color = "green";
            mensagem.textContent = "Login realizado com sucesso!";
        } else {
            mensagem.style.color = "red";
            mensagem.textContent = `Erro: ${texto}`;
        }
    } catch (erro) {
        mensagem.style.color = "red";
        mensagem.textContent = "Erro ao se conectar ao servidor";
        console.error(erro);
    }
});
